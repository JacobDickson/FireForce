
"use strict";

let Tag = require('./Tag.js');
let Anchor = require('./Anchor.js');

module.exports = {
  Tag: Tag,
  Anchor: Anchor,
};
