#!/usr/bin/python
#
# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
#

# 
# This was modified by Jacob Dickson
# 
#
import rospy


from localizer_dwm1001.msg      import Tag
from localizer_dwm1001.srv      import Tag_srv

import argparse
import sys
tag = Tag()
#def triggerResponseTag( request):
#    return (tag.x, tag.y, tag.z)


def TagCallback(data):
    #global tag
    tag.x = data.x
    tag.y = data.y
    tag.z = data.z


rospy.init_node("detectnet_camera", anonymous=False)

rospy.Subscriber("/dwm1001/tag",     Tag,    TagCallback)
#rospy.Service('/Tag',      Tag_srv,  triggerResponseTag)

# process frames until user exits
while 1:
	
	#logs data being published		
	rospy.loginfo(tag)
