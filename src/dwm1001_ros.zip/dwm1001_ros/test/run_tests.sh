#!/bin/bash
python test_Anchor_0.py
python test_Anchor_1.py
python test_Anchor_2.py
python test_Anchor_3.py
python test_Tag.py